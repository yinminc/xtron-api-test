### Included File
This is content that was included from another file! It's easy, simply use `include(filename)` in an HTML comment (`<!-- include... -->`).

Included files can include other files as well, allowing you to structure your API documentation as you see fit. Since Markdown supports inline HTML, the files you include can be *either* Markdown or HTML.
